package com.example.navigation_drawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
